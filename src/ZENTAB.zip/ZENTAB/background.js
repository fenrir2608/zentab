chrome.action.onClicked.addListener(() => {
    chrome.storage.local.get(['savedTabs'], (result) => {
      if (result.savedTabs && result.savedTabs.length > 0) {
        
        result.savedTabs.forEach(url => {
          chrome.tabs.create({ url });
        });
        

        chrome.storage.local.remove('savedTabs');
      } else {
        
        chrome.tabs.query({}, (tabs) => {
          const tabUrls = tabs.map(tab => tab.url);
          chrome.storage.local.set({ savedTabs: tabUrls }, () => {
            tabs.forEach(tab => {
              chrome.tabs.remove(tab.id);
            });
          });
        });
      }
    });
  });
  